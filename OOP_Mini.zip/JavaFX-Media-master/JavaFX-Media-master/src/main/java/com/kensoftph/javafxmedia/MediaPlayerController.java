package com.kensoftph.javafxmedia;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;
import javafx.util.Duration;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MediaPlayerController {

    @FXML
    private Button btnPlay;

    @FXML
    private Label lblDuration;

    @FXML
    private MediaView mediaView;

    @FXML
    private Slider slider;

    @FXML
    private Button btnNext;

    @FXML
    private Button btnPrevious;

    @FXML
    private ImageView albumCoverImageView;
    @FXML
    private Label lblCurrentSong;

    private StringProperty currentSongName = new SimpleStringProperty("");


    private Media media;
    private MediaPlayer mediaPlayer;
    private final Queue<File> mediaQueue = new LinkedList<>(); // Queue to store media files
    private boolean isPlayed = false;

    @FXML
    void btnPlay(MouseEvent event) {
        if (mediaPlayer != null) {
            if (mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING) {
                mediaPlayer.pause();
                btnPlay.setText("Play");
                isPlayed = false;
            } else {
                mediaPlayer.play();
                btnPlay.setText("Pause");
                isPlayed = true;
            }
        } else {
            playNextMedia();
        }
    }


    @FXML
    void btnStop(MouseEvent event) {
        btnPlay.setText("Play");
        mediaPlayer.stop();
        isPlayed = false;
    }

    @FXML
    void selectMedia(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Media Files");
        List<File> selectedFiles = fileChooser.showOpenMultipleDialog(null);

        if (selectedFiles != null && !selectedFiles.isEmpty()) {
            mediaQueue.addAll(selectedFiles);
            playNextMedia();
        }
    }

    @FXML
    void btnNext(ActionEvent event) {
        mediaPlayer.stop();
        playNextMedia();
    }

    @FXML
    void btnPrevious(ActionEvent event) {
        mediaPlayer.stop();
        if (!mediaQueue.isEmpty()) {
            // Add the currently playing media back to the queue
            mediaQueue.add(mediaQueue.poll());
        }
        playNextMedia();
    }

    private void playNextMedia() {
        if (!mediaQueue.isEmpty()) {
            File selectedFile = mediaQueue.poll();
            String url = selectedFile.toURI().toString();

            String filename = selectedFile.getName();
            int dotIndex = filename.lastIndexOf(".");
            if (dotIndex > 0) {
                filename = filename.substring(0, dotIndex);
            }

            currentSongName.set(filename); // Update the current song name
            media = new Media(url);

            mediaPlayer = new MediaPlayer(media);

            mediaPlayer.setOnReady(() -> {
                Image albumCoverImage = loadAlbumCoverImage(selectedFile);
                if (albumCoverImage != null) {
                    albumCoverImageView.setImage(albumCoverImage);
                } else {
                    // Set a default image if no album cover is found
                    albumCoverImageView.setImage(new Image("C:\\Users\\shrey\\Downloads\\music-transparent-png-800.png"));
                }

                Duration totalDuration = media.getDuration();
                slider.setMax(totalDuration.toSeconds());
                lblDuration.setText("Duration: 00 / " + (int) totalDuration.toSeconds());
                mediaPlayer.play();
                isPlayed = true;
                btnPlay.setText("Pause");
            });

            mediaView.setMediaPlayer(mediaPlayer);

            mediaPlayer.currentTimeProperty().addListener((observableValue, oldValue, newValue) -> {
                slider.setValue(newValue.toSeconds());
                lblDuration.setText("Duration: " + (int) slider.getValue() + " / " + (int) media.getDuration().toSeconds());
            });

            Scene scene = mediaView.getScene();
            mediaView.fitWidthProperty().bind(scene.widthProperty());
            mediaView.fitHeightProperty().bind(scene.heightProperty());
            lblCurrentSong.textProperty().bind(currentSongName);

        }
    }

    private Image loadAlbumCoverImage(File mediaFile) {
        // Implement this method to load the album cover image
        // from a specific location or source based on the media file.
        // You can use Java ImageIO, JavaFX Image, or any other suitable libraries for image loading.
        // Return the loaded image, or null if no album cover is found.
        return null; // Replace with actual code.
    }

    @FXML
    private void sliderPressed(MouseEvent event) {
        mediaPlayer.seek(Duration.seconds(slider.getValue()));
    }
}
